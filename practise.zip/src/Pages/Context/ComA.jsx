import ComB from './ComB'

export default function ComA() {
  return (
    <div>
        <ComB />
    </div>
  )
}
