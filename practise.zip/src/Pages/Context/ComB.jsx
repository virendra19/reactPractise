import ComC from "./ComC";

export default function ComB() {
  return (
    <div>
      <ComC />
    </div>
  );
}
